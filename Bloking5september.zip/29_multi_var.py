#Many Values to Multiple Variables
x, y, z = "Orange", "Banana", "cherry"
print(x)
print(y)
print(z)


#one Value to Multiple Variables
x = y = z = "Orange"
print(x)
print(y)
print(z)