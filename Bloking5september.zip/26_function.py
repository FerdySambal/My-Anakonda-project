#membuat function
def my_function():
    print("Hello From a function")

    #memanggil function
    my_function()