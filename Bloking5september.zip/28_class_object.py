#membuat class
class myClass:
    x = 5

#membuat objeck
p1 = myClass()

#mencetak nilai var x pada class myClass
print(p1.x)

